#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>
#include <limits.h>

//  you may need other standard header files

//  CITS2002 Project 1 2023
//  Student1:   23371027   Xiaoyu Huang
//  Student2:   23734789   Feiyue Zhang

//  myscheduler (v1.0)
//  Compile with:  cc -std=c11 -Wall -Werror -o myscheduler myscheduler.c
// ./myscheduler sysconfig-file.txt command-file.txt


//  THESE CONSTANTS DEFINE THE MAXIMUM SIZE OF sysconfig AND command DETAILS
//  THAT YOUR PROGRAM NEEDS TO SUPPORT.  YOU'LL REQUIRE THESE //  CONSTANTS
//  WHEN DEFINING THE MAXIMUM SIZES OF ANY REQUIRED DATA STRUCTURES.

#define MAX_DEVICES                     4
#define MAX_DEVICE_NAME                 20
#define MAX_COMMANDS                    10
#define MAX_COMMAND_NAME                20
#define MAX_SYSCALLS_PER_PROCESS        40
#define MAX_RUNNING_PROCESSES           50


//  NOTE THAT DEVICE DATA-TRANSFER-RATES ARE MEASURED IN BYTES/SECOND,
//  THAT ALL TIMES ARE MEASURED IN MICROSECONDS (usecs),
//  AND THAT THE TOTAL-PROCESS-COMPLETION-TIME WILL NOT EXCEED 2000 SECONDS
//  (SO YOU CAN SAFELY USE 'STANDARD' 32-BIT ints TO STORE TIMES).


#define DEFAULT_TIME_QUANTUM            100
#define TIME_CONTEXT_SWITCH             5
#define TIME_CORE_STATE_TRANSITIONS     10
#define TIME_ACQUIRE_BUS                20

//  ----------------------------------------------------------------------

#define CHAR_COMMENT                    '#'
#define BOOL int
#define TRUE 1
#define FALSE 0
#define INVALID_PID -9999999


typedef struct {
    char deviceName[50];  // device name
    long long int inputRate;  //  readspeed
    long long int outputRate; //  writespeed
} DeviceInfo;

//Globally define a structure array 'devices' and an integer 'deviceCount' to record the current number of stored devices
DeviceInfo devices[MAX_DEVICES]; 
int deviceCount = 0;

//Define time quantum
int timequantum = 0;


typedef struct {
    long long time;  // time
    char command[MAX_COMMAND_NAME]; // command
    char deviceName[MAX_DEVICE_NAME];  // device name
    char arg2[MAX_DEVICE_NAME];  // arg2 to recond the spawn process name
    long long dataSize;  // datasize
    long long Spendingtime;  // sleeping time, default 0
} CommandInfo;

// Define the enumeration type for process status
typedef enum {
    RUNNING,
    READY,
    BLOCKED,
    WAITING,
    EXIT
} ProcessState;

typedef struct ProgramInfo ProgramInfo;  // First, forward declare ProgramInfo

struct ProgramInfo {
    char programName[MAX_DEVICE_NAME];  // program name
    CommandInfo commands[MAX_SYSCALLS_PER_PROCESS];  // command array
    int commandCount;  // the amount of command 
    struct ProgramInfo *children[MAX_SYSCALLS_PER_PROCESS];          // sub-processes
    int totalRunTime;               // total running time for this process
    int elapsedRunTime;             // Running time elapsed
    ProcessState state;             // state 
    int pid;                        // pid
    int inlist;                     // if the program in list
};

ProgramInfo programs[MAX_RUNNING_PROCESSES];  // Global array of programs
int programCount = 0;  // Number of currently stored programs

typedef struct {
    int pid;
    long long int rate;
    long long dataSize;
} BlockQueueExitResult;

//execute
//Define a total timestamp
int total_time=0;
int running_timequantum = 0;

//Global process array
ProgramInfo* processList[MAX_RUNNING_PROCESSES];

int currentProcessCount = 0;
int currentPid=0;

void read_sysconfig(char argv0[], char filename[])
{

    FILE *file = fopen(filename, "r");
    if(!file) {
        printf("Error opening file: %s\n", filename);
        perror("Error opening file dabukai");
        exit(EXIT_FAILURE); 
    }
   
    // DeviceInfo device;

    char   line[BUFSIZ];

    while( fgets(line, sizeof line, file) != NULL ) {  
        // Skip lines starting with a '#' (comments).
        if(line[0] == CHAR_COMMENT) {
        continue;
        }
        // Define temporary variables to store the parsing results
        char deviceKeyword[50];
        char tempDeviceName[50];
        long long tempInputRate;
        long long tempOutputRate;
        if(strncmp(line, "timequantum", 11) == 0) {
        // Extract the numeric part after "timequantum".
        sscanf(line + 11, "%dusec", &timequantum);
        printf("Extracted value: %d\n", timequantum);
        }  
        running_timequantum = timequantum;

        // Use sscanf to parse the line
        if(sscanf(line, "%s %s %lldBps %lldBps", 
            deviceKeyword, 
            tempDeviceName, 
            &tempInputRate, 
            &tempOutputRate) == 4) {
            // Check if the first parsed string is "device"
            if(strcmp(deviceKeyword, "device") == 0) {
                if(deviceCount < MAX_DEVICES) {
                // Stored in a global array of device information structures
                strncpy(devices[deviceCount].deviceName, tempDeviceName, sizeof(devices[deviceCount].deviceName) - 1);
                devices[deviceCount].inputRate = tempInputRate;
                devices[deviceCount].outputRate = tempOutputRate;
                deviceCount++;
                // Output inspection results
                printf("%s\t%lldBps\t%lldBps\n", 
                devices[deviceCount-1].deviceName, 
                devices[deviceCount-1].inputRate, 
                devices[deviceCount-1].outputRate);
                } else {
                // Rows are not formatted correctly or as expected
                printf("Failed to parse line: %s", line);
                }   
            }
        }
    }
    fclose(file);
}

void read_commands(char argv0[], char filename[])
{

    FILE *file = fopen(filename, "r");
    if(!file) {
        printf("Error opening file: %s\n", filename);
        perror("Error opening file dabukai");
        exit(EXIT_FAILURE); 
    }

    char   line[BUFSIZ];
    BOOL   readingProgram = FALSE; // Flag to indicate whether a program is currently being read
    long long tempTime =0 ;
    char tempCommand[MAX_COMMAND_NAME]="";
    char tempDeviceName[MAX_DEVICE_NAME]="";
    char tempArg2[MAX_DEVICE_NAME]="";
    long long tempDataSize = 0;
    long long tempSpendingtime = 0;
    int tokenCount = 0;
    char* tokens[4]; //maximum 4

    while(fgets(line, sizeof line, file) != NULL) {
        // Try to read the command
        tempTime = 0;
        tempCommand[0] = '\0';
        tempDeviceName[0]= '\0' ;
        tempArg2[0]= '\0' ;
        tempDataSize = 0;
        tempSpendingtime = 0;
        tokenCount = 0;
        for (int i = 0; i < 4; i++) {
            tokens[i] = NULL;
        }   

        //  Skip lines starting with a '#' (comments)
        if(line[0] == CHAR_COMMENT) {
            readingProgram = TRUE;
            continue;
        }

        if(readingProgram) {
            // Try to read the program name
            char tempProgramName[MAX_DEVICE_NAME];
            if(sscanf(line, "%s", tempProgramName) == 1) {
                // Save to program array
                strncpy(programs[programCount].programName, tempProgramName, sizeof(programs[programCount].programName) - 1);
                programs[programCount].commandCount = 0;
                readingProgram = FALSE;
            }
        } else {
            char* token = strtok(line, " \t"); // Using spaces or tabs as separators
            while(token != NULL) {
                char* pos;
                if ((pos = strchr(token, '\n')) != NULL) {
                    *pos = '\0';
                }
                char* pos2;
                if ((pos2 = strchr(token, '\r')) != NULL) {
                    *pos2 = '\0';
                }
                if(tokenCount < 4) {
                    tokens[tokenCount++] = token;
                    
                }
                token = strtok(NULL, " \t");
            }   

            if(tokenCount == 3 && strcmp(tokens[1], "sleep") == 0) {
                //token 1 assignment
                printf("正确：行'%s'的格式正确\n", line);
                if(sscanf(tokens[0], "%lldusecs", &tempTime) != 1) {
                    printf("Error parsing time from: %s\n", tokens[0]);
                    exit(EXIT_FAILURE);
                }
                else{
                    printf("success parsing time from: %s\n", tokens[0]);
                }
                //token 2 assignment
                strncpy(tempCommand, tokens[1], sizeof(tempCommand) - 1);
                tempCommand[sizeof(tempCommand) - 1] = '\0'; // Make sure the string ends in null
                printf("tempCommand是%s\n",tempCommand);
                //token 3 assignment
                if(sscanf(tokens[2], "%lldusecs", &tempSpendingtime) != 1) {
                    printf("Error parsing data size from: %s\n", tokens[2]);
                    exit(EXIT_FAILURE);
                }
                else{
                    printf("success parsing time from: %s\n", tokens[2]);
                }

            } else if (tokenCount == 2) {
                //token 1 assignment
                if(sscanf(tokens[0], "%lldusecs", &tempTime) != 1) {
                    printf("Error parsing time from: %s\n", tokens[0]);
                    exit(EXIT_FAILURE);
                }
                else{
                    printf("success parsing time from: %s\n", tokens[0]);
                }
                //token 2 assignment
                strncpy(tempCommand, tokens[1], sizeof(tempCommand) - 1);
                tempCommand[sizeof(tempCommand) - 1] = '\0'; // Make sure the string ends in null
            } else if (tokenCount == 4 && (strcmp(tokens[1], "read") == 0 || strcmp(tokens[1], "write") == 0)) {
                //token 1 assignment
                if(sscanf(tokens[0], "%lldusecs", &tempTime) != 1) {
                    printf("Error parsing time from: %s\n", tokens[0]);
                    exit(EXIT_FAILURE);
                }
                else{
                    printf("success parsing time from: %s\n", tokens[0]);
                }
                //token 2 assignment
                strncpy(tempCommand, tokens[1], sizeof(tempCommand) - 1);
                tempCommand[sizeof(tempCommand) - 1] = '\0'; 
                //token 3 assignment
                strncpy(tempDeviceName, tokens[2], sizeof(tempDeviceName) - 1);
                tempDeviceName[sizeof(tempDeviceName) - 1] = '\0'; 
                //token 4 assignment
                if(sscanf(tokens[3], "%lldB", &tempDataSize) != 1) {
                    printf("Error parsing data size from: %s\n", tokens[3]);
                    exit(EXIT_FAILURE);
                }
                else{
                    printf("success parsing time from: %s\n", tokens[3]);
                }

            } else if(tokenCount == 3 && strcmp(tokens[1], "spawn") == 0) {
                 //token 1 assignment
                if(sscanf(tokens[0], "%lldusecs", &tempTime) != 1) {
                    printf("Error parsing time from: %s\n", tokens[0]);
                    exit(EXIT_FAILURE);
                }
                else{
                    printf("success parsing time from: %s\n", tokens[0]);
                }
                //token 2 assignment
                strncpy(tempCommand, tokens[1], sizeof(tempCommand) - 1);
                tempCommand[sizeof(tempCommand) - 1] = '\0'; 
                 //token 3 assignment
                strncpy(tempArg2, tokens[2], sizeof(tempArg2) - 1);
                tempArg2[sizeof(tempArg2) - 1] = '\0'; 

            } else {
                printf("error：row'%s'format incorrect\n", line);
            }

            // Storing commands to the current program's command list
            CommandInfo *currentCommand = &programs[programCount].commands[programs[programCount].commandCount];
            currentCommand->time = tempTime;
            strncpy(currentCommand->command, tempCommand, sizeof(currentCommand->command) - 1);
            strncpy(currentCommand->deviceName, tempDeviceName, sizeof(currentCommand->deviceName) - 1);
            strncpy(currentCommand->arg2, tempArg2, sizeof(currentCommand->arg2) - 1);
            if(tempDataSize) {
                currentCommand->dataSize = tempDataSize;
            }
            if(tempSpendingtime) {
                currentCommand->Spendingtime = tempSpendingtime;
            }
            printf("Time: %llu, Command: %s, Device Name: %s, Arg2: %s, Data Size: %lld, Spending Time: %lld\n", 
            currentCommand->time, currentCommand->command, currentCommand->deviceName, 
            currentCommand->arg2, currentCommand->dataSize, currentCommand->Spendingtime);

            programs[programCount].commandCount++;
            
            // Check to see if all the commands of a program have been read.

            printf("Value of tempCommand: '%s'\n", tempCommand);

            printf("Length of tempCommand: %ld\n", strlen(tempCommand));

            for(int i = 0; i < strlen(tempCommand); i++) {
            printf("%d ", tempCommand[i]);
            }
            printf("\n");

            if(strcmp(tempCommand, "exit") == 0) {
                printf("tempCommand: %s\n", tempCommand);
                programCount++;
                readingProgram = TRUE;
            }
            printf("programCount:%d\n",programCount);
        }

    }

    for (int i = 0; i < programCount; i++) {
        if (programs[i].commandCount > 0) {
            programs[i].totalRunTime = programs[i].commands[programs[i].commandCount - 1].time;
        } else {
            programs[i].totalRunTime = 0;
        }
        programs[i].elapsedRunTime=0;
    }
    
    if (programs[0].commandCount > 0) {
        programs[0].pid = 0 ;
    }
    
}

//  ----------------------------------------------------------------------


//-------------- -------------- --------------

//recursive (calculation)
void setExitState(ProgramInfo* program, int targetPid) 
{
    if (!program) 
    {
        return; // If program is null, return directly
    }

    // If matching PID is found, update the status and return
    if (program->pid == targetPid) 
    {
        program->state = EXIT;
        return;
    }

    // Otherwise, recursively call this function on each child process
    for (int i = 0; i < MAX_SYSCALLS_PER_PROCESS && program->children[i]; i++) 
    {
        setExitState(program->children[i], targetPid);
    }
}

ProgramInfo* findProgramInfoRecursive(ProgramInfo* program, int targetPid) {
    if (!program) {
        return NULL;
    }

    if (program->pid == targetPid) {
        return program;
    }

    for (int i = 0; i < MAX_SYSCALLS_PER_PROCESS && program->children[i]; i++) {
        ProgramInfo* found = findProgramInfoRecursive(program->children[i], targetPid);
        if (found) {
            return found;
        }
    }

    return NULL;
}

// devicePriority array
#define MAX_PRIORITY 4
char devicePriority[MAX_DEVICES][50];  // Used to store device names
int deviceReadspeedPriority[MAX_DEVICES]; // Used to store the readspeed priority of the device

void sortDevicesByReadspeed() {
    // Bubble sort the device array
    for (int i = 0; i < deviceCount - 1; i++) {
        for (int j = 0; j < deviceCount - i - 1; j++) {
            if (devices[j].inputRate > devices[j + 1].inputRate) {
                DeviceInfo temp = devices[j];
                devices[j] = devices[j + 1];
                devices[j + 1] = temp;
            }
        }
    }

    // Assign priority to devices
    int currentPriority = 0;
    long long int lastReadspeed = -1;
    for (int i = 0; i < deviceCount; i++) {
        strcpy(devicePriority[i], devices[i].deviceName);
        if (devices[i].inputRate != lastReadspeed) {
            deviceReadspeedPriority[i] = currentPriority;
            currentPriority++;
        } else {
            deviceReadspeedPriority[i] = currentPriority - 1;  // Give the same priority to devices with the same readspeed
        }
        lastReadspeed = devices[i].inputRate;
    }
}

int getDevicePriority(char* deviceName) {
    for (int i = 0; i < deviceCount; i++) {
        if (strcmp(devicePriority[i], deviceName) == 0) {
            return deviceReadspeedPriority[i];
        }
    }
    return -1;  // If the device name is not found in the array, return -1 to indicate it's invalid
}

//

//ready_queue --------

int readyQueue[MAX_RUNNING_PROCESSES] = { [0 ... MAX_RUNNING_PROCESSES-1] = INVALID_PID };
// Enter the ready queue
void enqueueToReady(int pid) {
    // Find the end of the queue
    int i = 0;
    while (i < MAX_RUNNING_PROCESSES && readyQueue[i] != INVALID_PID) {
        i++;
    }

    if (i == MAX_RUNNING_PROCESSES) {
        // The queue is full
        return;
    }

    // Add the new pid to the end of the queue
    readyQueue[i] = pid;
}
// Dequeue from the ready queue
int dequeueFromReady() {
    if (readyQueue[0] == INVALID_PID) {
    // The queue is empty
        return INVALID_PID;
    }

    int dequeuedPid = readyQueue[0];
    
    // Shift the other elements forward
    for (int i = 0; i < MAX_RUNNING_PROCESSES - 1; i++) {
        readyQueue[i] = readyQueue[i + 1];
    }
    readyQueue[MAX_RUNNING_PROCESSES - 1] = INVALID_PID;
    return dequeuedPid;
}
// check null
int isReadyQueueEmpty() {
    return readyQueue[0] == INVALID_PID;
}
//ready_queue --------

//running_queue --------
int runningQueue = INVALID_PID;
void enterRunningQueue(int pid) {
    if (runningQueue == INVALID_PID) {
        runningQueue = pid;
    }
    else{
        printf("error_node1\n");
    }  
}
// If the running queue is empty, return 0
int exitRunningQueue() {
    int previousRunning = runningQueue;
    runningQueue = INVALID_PID;
    return previousRunning;
}
//
int isRunningQueueEmpty() {
    return runningQueue == INVALID_PID;
}
// peek
int peekRunningQueue(){
    return runningQueue;
}
// This function checks if the first process in the running queue has finished
int isRunningQueueFirstFinished() {
    int firstPid = peekRunningQueue(); 
    if (firstPid == INVALID_PID) {
        return 0; // If the running queue is empty, return 0
    }

    ProgramInfo* currentProgram = findProgramInfoRecursive(processList[0], firstPid);
    if (!currentProgram) {
        return 0;
    }
    
    return (currentProgram->elapsedRunTime >= currentProgram->totalRunTime);
}
//running_queue --------

//block_queue --------

int blockQueue[4][MAX_RUNNING_PROCESSES] = {
    [0 ... 3][0 ... MAX_RUNNING_PROCESSES-1] = INVALID_PID
};


long long getDeviceRate(char *deviceName, char *command) {
    for (int i = 0; i < deviceCount; i++) {
        if (strcmp(devices[i].deviceName, deviceName) == 0) {
            if (strcmp(command, "write") == 0) {
                return devices[i].outputRate;
            } else if (strcmp(command, "read") == 0) {
                return devices[i].inputRate;
            }
        }
    }
    return INVALID_PID;  // If the device is not found or the command is invalid
}

void enterBlockQueue(int pid, CommandInfo command) {
    long long rate = getDeviceRate(command.deviceName, command.command);
    int dataSize = command.dataSize;

    int priority = getDevicePriority(command.deviceName);

    int index = MAX_RUNNING_PROCESSES - 1;
    while (index > 0) {
        if (priority <= blockQueue[3][index - 1]) {
            break;
        }
        blockQueue[0][index] = blockQueue[0][index - 1];
        blockQueue[1][index] = blockQueue[1][index - 1];
        blockQueue[2][index] = blockQueue[2][index - 1];
        blockQueue[3][index] = blockQueue[3][index - 1];
        index--;
    }

    blockQueue[0][index] = pid;
    blockQueue[1][index] = rate;
    blockQueue[2][index] = dataSize;
    blockQueue[3][index] = priority;

}

BlockQueueExitResult exitBlockQueue() { 
    BlockQueueExitResult result;
    result.pid = blockQueue[0][0];
    result.rate = blockQueue[1][0];
    result.dataSize = blockQueue[2][0];

    for (int i = 0; i < MAX_RUNNING_PROCESSES - 1; i++) {
        blockQueue[0][i] = blockQueue[0][i + 1];
        blockQueue[1][i] = blockQueue[1][i + 1];
        blockQueue[2][i] = blockQueue[2][i + 1];
        blockQueue[3][i] = blockQueue[3][i + 1];
    }
    blockQueue[0][MAX_RUNNING_PROCESSES - 1] = INVALID_PID;
    blockQueue[1][MAX_RUNNING_PROCESSES - 1] = INVALID_PID;
    blockQueue[2][MAX_RUNNING_PROCESSES - 1] = INVALID_PID;
    blockQueue[3][MAX_RUNNING_PROCESSES - 1] = INVALID_PID;
    
    return result;
}
// peek
BlockQueueExitResult peekBlockQueue() {
    BlockQueueExitResult data;
    data.pid = blockQueue[0][0];
    data.rate = blockQueue[1][0];
    data.dataSize = blockQueue[2][0];
    return data;
}
// check
int isBlockQueueEmpty() {
    return blockQueue[0][0] == INVALID_PID;
}
//block_queue --------

//waiting_queue --------
int waitingQueue[MAX_RUNNING_PROCESSES] = { [0 ... MAX_RUNNING_PROCESSES-1] = INVALID_PID };

void enterWaitingQueue(int pid) {
    for (int i = 0; i < MAX_RUNNING_PROCESSES; i++) {
        if (waitingQueue[i] == INVALID_PID) {
            waitingQueue[i] = pid;
            break;
        }
    }
}

//  Helper function: Check if the state of the process and all its child processes is EXIT.
int areAllChildrenExited(ProgramInfo* program) {
    if (program->state != EXIT) {
        return 0;
    }
    for (int i = 0; i < MAX_SYSCALLS_PER_PROCESS && program->children[i] != NULL; i++) {
        if (program->children[i]->inlist != 1) {
            return 0;
        }
        if (!areAllChildrenExited(program->children[i])) {
            return 0;
        }
    }
    return 1;
}
//waiting to ready
int areAllDescendantsExited(ProgramInfo* program) {
    if (!program) {
        return 1; //  If the given structure is null, return 1 for "yes" (consider changing to 0 based on context).
    }
    // Add debug output to check the state of the process
    printf("Checking PID: %d, State: %d\n", program->pid, program->state);

    // Traverse all child processes and recursively check their states.
    for (int i = 0; i < MAX_SYSCALLS_PER_PROCESS && program->children[i]; i++) {
        if (program->children[i]) {
            printf("Checking child at index %d, with PID: %d\n", i, program->children[i]->pid);
            
            // If the state of the child process is not EXIT.
            if (program->children[i]->state != EXIT) {
                printf("THIS program name = %s\n",program->children[i]->programName);
                return 0;
            }
            
            // Recursively check the children of the child process.
            if (!areAllDescendantsExited(program->children[i])) {
                return 0; //  If the state of any child process or its descendants is not EXIT, return 0.
            }
        }
    }

    return 1; //  If all child processes and their descendants are in the EXIT state, return 1.
}

ProgramInfo* findProgramByPid(ProgramInfo* program, int targetPid) {
    if (!program) {
        return NULL;
    }

    if (program->pid == targetPid) {
        return program;
    }

    for (int i = 0; i < MAX_SYSCALLS_PER_PROCESS && program->children[i]; i++) {
        ProgramInfo* found = findProgramByPid(program->children[i], targetPid);
        if (found) {
            return found;
        }
    }

    return NULL;
}

int shouldExitWaitingQueue(ProgramInfo* processList[], int targetPid) {
    ProgramInfo* targetProgram = findProgramByPid(processList[0], targetPid);  // Assuming processList[0] is the root
    if (!targetProgram) {
        printf("Program with PID %d not found!\n", targetPid);
        return 0;
    }
    return areAllDescendantsExited(targetProgram);
}


//check
int isWaitingQueueEmpty() {
    for (int i = 0; i < MAX_RUNNING_PROCESSES; i++) 
    {
        if (waitingQueue[i]!=INVALID_PID)
        {
           return 0;
        }   
    }
    return 1;
}
//waiting_queue --------

//DataBus --------
int DataBus[2][1] = {{INVALID_PID}, {INVALID_PID}};

void enterDataBus(int pid, long long rate, int dataSize) {
    if (DataBus[0][0] == INVALID_PID) {
        DataBus[0][0] = pid;
        double endTime = total_time + (double)dataSize / rate * 1000000;
       
        // Custom rounding up operation.
        DataBus[1][0] = (int)endTime;
        if (endTime > (int)endTime) {
            DataBus[1][0]++;
        }
        // Every entry to the data bus costs 20s.
        DataBus[1][0] = DataBus[1][0] + 20;
        //extra second?
        // DataBus[1][0] = DataBus[1][0] + 1;
    } else {
        printf("DataBus is occupied.\n");
    }
}

int exitDataBus() {
    int pid = DataBus[0][0];
    DataBus[0][0] = INVALID_PID;
    DataBus[1][0] = INVALID_PID;
    return pid;
}
//check null
int isDataBusEmpty() {
    return DataBus[0][0] == INVALID_PID;
}
//DataBus --------

CommandInfo* findMatchingCommand(int pid) {
    ProgramInfo* program = findProgramInfoRecursive(processList[0], pid);
    if (program) {
        for (int j = 0; j < program->commandCount; j++) {
            if (program->commands[j].time == program->elapsedRunTime) {
                return &program->commands[j];
            }
        }
    }
    return NULL;
}
//
int visited[50][50];


void recordVisit(int pid, int time) {
    for (int i = 0; i < 50; i++) {
        if (visited[pid][i] == INVALID_PID) {
            visited[pid][i] = time;
            break;
        }
    }
}

int findVisit(int pid, int time) {
    for (int i = 0; i < 50; i++) {
        if (visited[pid][i] == time) {
            return 1;  
        }
    }
    return 0;  
}

// sleeping queue
long long int sleepingQueue[MAX_RUNNING_PROCESSES][2];  // 0th column for pid, 1st column for endsleep

// Function to enter sleeping
void enterSleeping(int pid, long long int spendingTime) {
    for (int i = 0; i < MAX_RUNNING_PROCESSES; i++) {
        if (sleepingQueue[i][0] == LLONG_MAX) {  // Find the first empty slot

            sleepingQueue[i][0] = pid;
            if ((total_time + spendingTime >= 10))
            {
                sleepingQueue[i][1] = total_time + spendingTime +1 ;  // Calculate endsleep + extra time 12
            }
            else{
                sleepingQueue[i][1] = 1; //extra time 12
            }
            
            printf("pid = %lld , endtime = %lld\n",sleepingQueue[i][0],sleepingQueue[i][1]);
            break;
        }
    }
}

// Dequeue function.
int exitSleeping() {
    for (int i = 0; i < MAX_RUNNING_PROCESSES; i++) {
        if (sleepingQueue[i][0] != LLONG_MAX && sleepingQueue[i][1] <= total_time) {
            int pid = (int) sleepingQueue[i][0];
            sleepingQueue[i][0] = LLONG_MAX;
            sleepingQueue[i][1] = LLONG_MAX;
            return pid;
        }
    }
    return -1;  //  If no process meets the condition, return -1.
}

//  Used to check if the sleepingQueue is empty.
int isSleepingQueueEmpty() {
    for (int i = 0; i < MAX_RUNNING_PROCESSES; i++) {
        if (sleepingQueue[i][0] != LLONG_MAX) {
            return 0;  //  Used to check if the sleepingQueue is empty.
        }
    }
    return 1;  // All slots are empty.
}
// ----------------------
//bug test print void
    void printAllPids(struct ProgramInfo* program) {
    if (!program) {
        return;
    }

    //  Print the current program's pid.
    printf("PID: %d\n", program->pid);

    // Recursively traverse all child processes and print their pids.
    for (int i = 0; i < MAX_SYSCALLS_PER_PROCESS && program->children[i]; i++) {
        printAllPids(program->children[i]);
    }
}
//
//final cpu running time add up
int recursiveSumLastCommandTime(ProgramInfo* program) {
    if (!program) {
        return 0;
    }

    int sum = 0;

    // Check if the process has commands and add the time of the last command to the total.
    if (program->commandCount > 0) {
        sum += program->commands[program->commandCount - 1].time;
    }

    // Recursively traverse all child processes and accumulate the time of their last command.
    for (int i = 0; i < MAX_SYSCALLS_PER_PROCESS && program->children[i]; i++) {
        sum += recursiveSumLastCommandTime(program->children[i]);
    }

    return sum;
}

int sumLastCommandTimeForFirstProgram(ProgramInfo* processList[]) {
    //  Ensure the first element of processList exists.
    if (!processList[0]) {
        return 0;
    }
    
    return recursiveSumLastCommandTime(processList[0]);
}
//

//-------------- -------------- --------------
void execute_commands(void)
{   
    //  Initialize Sleeping queue.
    for (int i = 0; i < MAX_RUNNING_PROCESSES; i++) {
        sleepingQueue[i][0] = LLONG_MAX;  // use the maximum value of long long int to represent null
        sleepingQueue[i][1] = LLONG_MAX;
    }
    //  Initialize visited array.
    for (int i = 0; i < 50; i++) {
        for (int j = 0; j < 50; j++) {
            visited[i][j] = INVALID_PID;
        }
    }
    //initial process list
    for (int i = 0; i < MAX_RUNNING_PROCESSES; i++) {
    processList[i] = NULL;
    }
    //initial 
    sortDevicesByReadspeed();

    // By default, put the first program into the ready queue.
    processList[0] = &programs[0];
    // Set the state of programs[0] to RUNNING. and inlist = 1
    processList[0]->pid = 0;
    processList[0]->inlist = 1;
    // enqueue pid 0 to ready queue
    enqueueToReady(0);
    int cpu = 0;// cpu node (0 represent cpu is not working , 1 represent cpu is working)
    while (!isReadyQueueEmpty() || !isBlockQueueEmpty() || !isWaitingQueueEmpty() || !isRunningQueueEmpty()|| !isSleepingQueueEmpty()) {
        
        int tempid = INVALID_PID;
        
        // check sleep queue
        // 1. unblock any sleeping processes
        if (!isSleepingQueueEmpty())
        {   
            if(cpu == 0){
                for (int i = 0; i < MAX_RUNNING_PROCESSES; i++) {
                    if (sleepingQueue[i][1] <= total_time) {
                        int pid = (int)sleepingQueue[i][0]; 
                        enqueueToReady(pid);  // enqueue pid to ready queue
                        total_time = total_time + 10;
                        sleepingQueue[i][0] = LLONG_MAX;
                        sleepingQueue[i][1] = LLONG_MAX;
                        goto start_of_while;  // This will go directly to the next while loop
                    }
                }
            }
        }
        // 2.unblock any processes waiting for all their spawned processes (children) to terminate
          if (!isWaitingQueueEmpty())
        {   
            
           for (int i = 0; i < MAX_RUNNING_PROCESSES; i++)
           {    
                if (waitingQueue[i]!= INVALID_PID)
                {
                    int pid = waitingQueue[i];
                    printf("pid in waiting: %d\n",pid);
                    if (shouldExitWaitingQueue(processList, pid)) {
                        // Remove the PID from the waitingQueue
                        waitingQueue[i] = INVALID_PID;
                        // Add this program to the ready queue                      
                        enqueueToReady(pid);
                        total_time = total_time + 10;
                        goto start_of_while;  // This will go directly to the next iteration of the while loop
                    }
                } 
            } 
            
        }
        
        // 3.unblock any completed I/O
        if (!isDataBusEmpty())
        {   
            if(cpu == 0){
                
                if ((DataBus[1][0] == total_time) || (DataBus[1][0] < total_time)) {
                   
                    int pidFromDataBus = exitDataBus();
                    int pidIndexInBlockQueue = -1;

                    // Find the position of this PID in the block queue
                    for (int i = 0; i < MAX_RUNNING_PROCESSES; i++) {
                        if (blockQueue[0][i] == pidFromDataBus) {
                            pidIndexInBlockQueue = i;
                            
                            break;
                        }
                    }
                    
                    // If this PID is found in the block queue
                    if (pidIndexInBlockQueue != -1) {
                        BlockQueueExitResult data;
                        data.pid = blockQueue[0][pidIndexInBlockQueue];
                        data.rate = blockQueue[1][pidIndexInBlockQueue];
                        data.dataSize = blockQueue[2][pidIndexInBlockQueue];

                        // Move the elements after this PID forward to overwrite it
                        for (int i = pidIndexInBlockQueue; i < MAX_RUNNING_PROCESSES - 1; i++) {
                            blockQueue[0][i] = blockQueue[0][i + 1];
                            blockQueue[1][i] = blockQueue[1][i + 1];
                            blockQueue[2][i] = blockQueue[2][i + 1];
                            blockQueue[3][i] = blockQueue[2][i + 1];
                        }
                        blockQueue[0][MAX_RUNNING_PROCESSES - 1] = INVALID_PID;
                        blockQueue[1][MAX_RUNNING_PROCESSES - 1] = INVALID_PID;
                        blockQueue[2][MAX_RUNNING_PROCESSES - 1] = INVALID_PID;
                        blockQueue[3][MAX_RUNNING_PROCESSES - 1] = INVALID_PID;

                        enqueueToReady(data.pid);
                        total_time = total_time + 10;
                    }

                goto start_of_while;  
                }
            }
        }
        //
        // 4.commence any pending I/O
        if (isDataBusEmpty())
        {
            if (!isBlockQueueEmpty())
            {
                // Peek the first process from blockQueue
                BlockQueueExitResult data = peekBlockQueue();
        
                // Put the first PID from blockQueue into DataBus and calculate the end time
                enterDataBus(data.pid, data.rate, data.dataSize);
            }
        }
        // 5. commence/resume the next READY process
        if (isRunningQueueEmpty()){
            
            tempid = dequeueFromReady();
            
            if (tempid !=INVALID_PID){
                enterRunningQueue(tempid);
                running_timequantum = timequantum;
                total_time = total_time + 5;
                goto start_of_while;  
            }
        }
        
        
        if (!isRunningQueueEmpty())
        {
            
            if (running_timequantum > 0)
            {
                int runningPid = peekRunningQueue();

                ProgramInfo* matchedProgram = NULL;
                ProgramInfo* currentProgram = findProgramInfoRecursive(processList[0], runningPid);
                if (currentProgram) {
                    matchedProgram = currentProgram;
                }

                if (!matchedProgram) {
                    printf("pid：%d No structure was found for the corresponding pid\n",runningPid);
                }

                BOOL foundTimeMatch = FALSE;

                if (matchedProgram)
                {   
                    for (int i = 0; i < matchedProgram->commandCount; i++) {
                        if ((matchedProgram->commands[i].time == (long long int)matchedProgram->elapsedRunTime)&&!findVisit(runningPid,matchedProgram->commands[i].time)) {
                            foundTimeMatch = true;
                            break;
                        } 
                    }
                    
                    if (!foundTimeMatch) {
                        cpu = 1;// cpu status update
                        matchedProgram->elapsedRunTime++;
                        running_timequantum--;
                        total_time++;                   
                        goto start_of_while;
                    }
                }
            
            }
            // running out of time quantum
            if (running_timequantum <= 0)
            {   
                int pidtomove = exitRunningQueue();
                cpu = 0; // update
                enqueueToReady(pidtomove);
                total_time = total_time + 10;
                running_timequantum = timequantum;
                goto start_of_while;
            }
            
            int runningPid = peekRunningQueue();
            CommandInfo* matchedCommand = findMatchingCommand(runningPid);
            
            if (matchedCommand)
            {
                cpu = 0;
                if (strcmp(matchedCommand->command, "read") == 0 || strcmp(matchedCommand->command, "write") == 0) 
                {   
                    int TempPid = exitRunningQueue();

                    enterBlockQueue(TempPid, *matchedCommand);

                    printf("matchedCommand time= %lld\n", matchedCommand->time);

                    int temptime = (int)matchedCommand->time;

                    recordVisit(TempPid, temptime); 
                    
                    total_time = total_time + 10;
                    total_time++; //extra second 3
                    
                    goto start_of_while;  
                }

                if (strcmp(matchedCommand->command, "spawn") == 0)
                {   
                    for (int i = 0; i < MAX_RUNNING_PROCESSES; i++) 
                    {  
                        if (strcmp(programs[i].programName, matchedCommand->arg2) == 0)
                        {
                            // Find the target programinfo
                            ProgramInfo targetProgram = programs[i];
                           
                            // Create a new programinfo structure identical to this target programinfo
                            ProgramInfo* a2 = (ProgramInfo*)malloc(sizeof(ProgramInfo));
                            if (!a2) {
                                exit(1);
                            }
                           
                            *a2 = targetProgram;  // copy programinfo
                            // 3. Label its PID as currentPid + 1
                           
                            a2->pid = currentPid + 1;
                          
                            // 4. Add a2 to the children array inside the programinfo structure in processList that has the same PID as in the running queue

                            // Use a recursive function to find the ProgramInfo that matches the runningPid.
                            ProgramInfo* runningProgram = findProgramInfoRecursive(processList[0], runningPid);
                            if (!runningProgram) {
                                printf("Error: Program with PID %d not found!\n", runningPid);
                                return;  
                            }
                            for (int j = 0; j < MAX_SYSCALLS_PER_PROCESS; j++)
                            {
                                if (runningProgram->children[j] == NULL)
                                {
                                    runningProgram->children[j] = a2;
                                    break;
                                }
                            }
                          
                            printAllPids(processList[0]);

                            // 5. Add the PID of a2 to the ready queue
                            enqueueToReady(a2->pid);  

                            // 6. Put the PID from the current running queue into the ready queue
                            int tempPid = exitRunningQueue();
                            enqueueToReady(tempPid);

                            int temptime = (int)matchedCommand->time;

                            recordVisit(tempPid, temptime);

                            total_time = total_time + 10;
                            total_time ++;   // extra second 
                            // 7. Then increase currentPid by 1
                            currentPid++;

                            // 8. Jump to the beginning of the while loop
                            goto start_of_while;
                        }
                    }
                }
                
                if (strcmp(matchedCommand->command, "sleep") == 0)
                {
                    int tempPid = exitRunningQueue();
                    total_time++; //extra second 
                    enterSleeping(tempPid,matchedCommand->Spendingtime);
                    
                    int temptime = (int)matchedCommand->time;
                    
                    recordVisit(tempPid, temptime); 

                    total_time = total_time +10; 
                    
                    goto start_of_while;
                }

                if (strcmp(matchedCommand->command, "wait") == 0)
                {   
                    int tempPid = exitRunningQueue();
                    enterWaitingQueue(tempPid);

                    int temptime = (int)matchedCommand->time;
                    printf("temp time = %d\n", temptime);

                    recordVisit(tempPid, temptime); 

                    total_time = total_time + 10;
                    total_time++; //extra second 
                    
                    goto start_of_while;
                }

                if (strcmp(matchedCommand->command, "exit") == 0)
                {   
                    
                    int tempPid = exitRunningQueue();
                    // Use a recursive function to find the ProgramInfo that matches the runningPid.
                    setExitState(processList[0], tempPid);  
                   
                    int temptime = (int)matchedCommand->time;
                    recordVisit(tempPid, temptime); 
                }

            }
            
        }
        
        total_time++;
        // printf("total_time: %d\n", total_time);
        start_of_while:  // lebal 
    }

}

//  ----------------------------------------------------------------------

int main(int argc, char *argv[])
{
//  ENSURE THAT WE HAVE THE CORRECT NUMBER OF COMMAND-LINE ARGUMENTS
    if(argc != 3) {
        printf("Using method：%s sysconfig_file_name command_file_name\n", argv[0]);
        exit(EXIT_FAILURE);
    }
//  READ THE SYSTEM CONFIGURATION FILE
    read_sysconfig(argv[0], argv[1]);

//  READ THE COMMAND FILE
    read_commands(argv[0], argv[2]);
    
//  EXECUTE COMMANDS, STARTING AT FIRST IN command-file, UNTIL NONE REMAIN
    execute_commands();

//  PRINT THE PROGRAM'S RESULTS
    int cputime = sumLastCommandTimeForFirstProgram(processList);
    int percentage = (int)(100.0 * cputime / total_time);
    printf("measurements  %d  %d\n",total_time, percentage);
    exit(EXIT_SUCCESS);
}

//  vim: ts=8 sw=4
