#include "mysync.h"

// cc -std=c11 -Wall -Werror -o mysync mysync.c
//./mysync  [options]  directory1  directory2  [directory3  ...]
void usage()
{
    printf("Usage: ./mysync [options] directories...\n");
    printf(" -a synchronize all files \n");
    printf(" -i pattern ignore files matching the pattern  \n");
    printf(" -n report actions that would be performed, but do not synchronize  \n");
    printf(" -o pattern only synchronize files matching the pattern  \n");
    printf(" -p preserve modification times and protection modes  \n");
    printf(" -r recursively synchronize directories  \n");
    printf(" -v be verbose and report actions  \n");
}


int main(int argc, char *argv[])
{
    int opt;
    // int verbose_flag = 0;  // For -v
    int aflag = 0;
    int nflag = 0;
    int pflag = 0;
    int rflag = 0;
    int vflag = 0;

    // Parsing command line arguments
    while ((opt = getopt(argc, argv, "ai:no:prv")) != -1)
    {
        switch (opt)
        {
        case 'a':
            aflag = 1;
            break;
        case 'i':
            {   
                char* globPattern = optarg;
                if (isDirectory(globPattern)) {
                    fprintf(stderr, "Error: -i option expects a glob pattern, not a directory\n");
                    usage();
                    exit(EXIT_FAILURE);
                }
                addPattern(&iPatterns, &iPatternCount, globPattern);
            }
            break;
        case 'n':
            nflag = 1;
            break;
        case 'o':
            {
                char* globPattern = optarg;
                if (isDirectory(globPattern)) {
                    fprintf(stderr, "Error: -i option expects a glob pattern, not a directory\n");
                    usage();
                    exit(EXIT_FAILURE);
                }
                addPattern(&oPatterns, &oPatternCount, globPattern);
            }
            break;
        case 'p':
            pflag = 1;
            break;
        case 'r':
            rflag = 1;
            break;
        case 'v':
            vflag = 1;
            break;
        default:
            usage();
            exit(EXIT_FAILURE);
        }
    }

    // Parsing Non-Option Parameters -- Directory
    for (int index = optind; index < argc; index++)
    {       
        printf("Non-option argument: %s\n", argv[index]);
        // TODO: handle directory or file args
        addDirectoryInfo(argv[index], argv[index]);
        size_t directoryIndex = directoryCount - 1;
        if ((aflag == 1)&&(rflag == 1))
        {
            readDirectory2(directoryIndex,argv[index]);
        }
        else{
            readDirectory(directoryIndex,argv[index],aflag,rflag);
        }
    }
    if ( (vflag ==1) || (nflag == 1) ){
        printFileNames();
    }
    synchronizeDirectories(nflag, pflag);
    freeFileInfos();
    freeDirectories();
    exit(EXIT_SUCCESS);
}