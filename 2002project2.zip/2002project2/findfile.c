#include "mysync.h"

// Dynamic array for storing file information
FileInfo* fileInfos = NULL;
size_t fileInfoCount = 0;

DirectoryInfo* directories = NULL;
size_t directoryCount = 0;

void addDirectoryInfo(const char* dirPath, const char* dirName) {
    directories = realloc(directories, (directoryCount + 1) * sizeof(DirectoryInfo));
    if (directories == NULL) {
        reportError("Memory allocation failed");
    }
    directories[directoryCount].dirName = strdup(dirName);
    directories[directoryCount].fullPath = strdup(dirPath);
    directories[directoryCount].fileInfos = NULL;
    directories[directoryCount].fileInfoCount = 0;
    directoryCount++;
}


// Functions to add file information to dynamic arrays
void addFileInfo(const char* path, const char* name, time_t modTime, mode_t mode) {
    // First check for the existence of an old file with the same name
    for (size_t i = 0; i < fileInfoCount; ++i) {
        if (strcmp(fileInfos[i].name, name) == 0) {
            // found an old file with the same name, check the modification time
            if (fileInfos[i].modifiedTime < modTime) {
                // The new file was modified more recently, updating the old file with information from the new file
                fileInfos[i].modifiedTime = modTime;
                fileInfos[i].fileMode = mode;
                fileInfos[i].path = strdup(path);
                // Splice path and name into fullPath.
                size_t fullPathLen = strlen(path) + strlen(name) + 2; // 1 for '/' and 1 for '\0'
                snprintf(fileInfos[i].fullPath, fullPathLen, "%s/%s", path, name);
                return; 
            } else {
                return; 
            }
        }
    }

    FileInfo newFileInfo;
    newFileInfo.path = strdup(path);
    newFileInfo.name = strdup(name);
    newFileInfo.modifiedTime = modTime;
    newFileInfo.fileMode = mode;
    // Calculate the length needed for fullPath
    size_t fullPathLen = strlen(path) + strlen(name) + 2; // 1 for '/' and 1 for '\0'
    // Allocate memory for fullPath
    newFileInfo.fullPath = malloc(fullPathLen);
    if (newFileInfo.fullPath == NULL) {
        reportError("Memory allocation failed1");
    }
    // Splice path and name into fullPath.
    snprintf(newFileInfo.fullPath, fullPathLen, "%s/%s", path, name);

    if (newFileInfo.path && newFileInfo.name && newFileInfo.fullPath) {
        fileInfos = realloc(fileInfos, (fileInfoCount + 1) * sizeof(FileInfo));
        if (fileInfos) {
            fileInfos[fileInfoCount] = newFileInfo;
            fileInfoCount++;
        }
        else {
            reportError("Memory allocation failed2");
        }
    }
}


void addFileInfoToDirectory(size_t directoryIndex, const char* path, const char* name, time_t modTime, mode_t mode) {
    if (directoryIndex >= directoryCount) {
        reportError("Invalid directory index");
    }
    DirectoryInfo* dirInfo = &directories[directoryIndex];
    FileInfo newFileInfo;
    newFileInfo.path = strdup(path);
    newFileInfo.name = strdup(name);
    newFileInfo.modifiedTime = modTime;
    newFileInfo.fileMode = mode;
    size_t fullPathLen = strlen(path) + strlen(name) + 2;  // 1 for '/' and 1 for '\0'
    newFileInfo.fullPath = malloc(fullPathLen);
    if (newFileInfo.fullPath == NULL) {
        reportError("Memory allocation failed3");
    }
    snprintf(newFileInfo.fullPath, fullPathLen, "%s/%s", path, name);

    if (newFileInfo.path && newFileInfo.name && newFileInfo.fullPath) {
        dirInfo->fileInfos = realloc(dirInfo->fileInfos, (dirInfo->fileInfoCount + 1) * sizeof(FileInfo));
        if (dirInfo->fileInfos) {
            dirInfo->fileInfos[dirInfo->fileInfoCount] = newFileInfo;
            dirInfo->fileInfoCount++;
        }
        else {
            reportError("Memory allocation failed4");
        }
    }
}

// Recursive function to read files and paths in a directory
void readDirectory(size_t directoryIndex, const char* directory, int aflag, int rflag) {
    int Aflag = aflag;
    int Rflag = rflag;
    DIR* dir = opendir(directory);
    if (dir) {
        struct dirent* entry;
        while ((entry = readdir(dir))) {
            // Ignore files that start with the "." or ".."character based on aflag. character
            if (!Aflag && (entry->d_name[0] == '.' || strncmp(entry->d_name, "..", 2) == 0)) continue;
            char path[PATH_MAX];
            snprintf(path, sizeof(path), "%s/%s", directory, entry->d_name);

            struct stat path_stat;
            stat(path, &path_stat);

            if (S_ISDIR(path_stat.st_mode)) {
                // Decide whether to process subdirectories recursively based on rflag.
                if (Rflag){
                    readDirectory(directoryIndex, path, Aflag, Rflag);
                } 
            } 
            else if (S_ISREG(path_stat.st_mode)) {
                // Check if there is a -i or -o mode specified.
                if ((iPatternCount > 0 || oPatternCount > 0) &&
                    (isFileMatchingPatterns(iPatterns, iPatternCount, entry->d_name) ||
                    (!isFileMatchingPatterns(oPatterns, oPatternCount, entry->d_name) && oPatternCount > 0))) {
                    continue;  // Ignore this file or directory
                }
                addFileInfoToDirectory(directoryIndex, directory, entry->d_name, path_stat.st_mtime, path_stat.st_mode);
                addFileInfo(directory, entry->d_name, path_stat.st_mtime, path_stat.st_mode);
            }
        }
        closedir(dir);
    }else{
        perror("opendir fail");
        exit(EXIT_FAILURE);
    }
}


void readDirectory2(size_t directoryIndex, const char* directory) {
    DIR* dir = opendir(directory);
    if (dir) {
        struct dirent* entry;
        while ((entry = readdir(dir))) {
            if (strcmp(entry->d_name, ".") != 0 && strcmp(entry->d_name, "..") != 0) {
                
                char path[PATH_MAX];
                snprintf(path, sizeof(path), "%s/%s", directory, entry->d_name);
                
                struct stat path_stat;
                stat(path, &path_stat);
                if (S_ISDIR(path_stat.st_mode)) {
                    readDirectory2(directoryIndex, path);
                } else if (S_ISREG(path_stat.st_mode)) {
                    if ((iPatternCount > 0 || oPatternCount > 0) &&
                        (isFileMatchingPatterns(iPatterns, iPatternCount, entry->d_name) ||
                        (!isFileMatchingPatterns(oPatterns, oPatternCount, entry->d_name) && oPatternCount > 0))) {
                        continue;  
                    }
                    // If it's a normal file, add it to the file info array
                    addFileInfoToDirectory(directoryIndex, directory, entry->d_name, path_stat.st_mtime, path_stat.st_mode);
                    addFileInfo(directory, entry->d_name, path_stat.st_mtime, path_stat.st_mode);
                }
            }
        }
        closedir(dir);
    }
    else{
        perror("opendir fail");
        exit(EXIT_FAILURE);
    }
}


// Function to release file information from dynamic arrays
void freeFileInfos() {
    for (size_t i = 0; i < fileInfoCount; i++) {
        free(fileInfos[i].path);
        free(fileInfos[i].name);
        free(fileInfos[i].fullPath);
    }
    free(fileInfos);
}

void freeDirectories() {
    for (size_t i = 0; i < directoryCount; ++i) {
        for (size_t j = 0; j < directories[i].fileInfoCount; ++j) {
            free(directories[i].fileInfos[j].path);
            free(directories[i].fileInfos[j].name);
            free(directories[i].fileInfos[j].fullPath);
        }
        free(directories[i].fileInfos);
        free(directories[i].dirName);
        free(directories[i].fullPath);
    }
    free(directories);
}