#include "mysync.h"


// Generic Error Reporting Functions
void reportError(const char *errorMessage) {
    fprintf(stderr, "Error: %s\n", errorMessage);
    exit(EXIT_FAILURE); // Termination procedures
}

char *strdup(const char *str) {
    size_t len = strlen(str) + 1;
    char *new_str = malloc(len);
    if (new_str == NULL) {
        reportError("Memory allocation failed");
    }
    memcpy(new_str, str, len);
    return new_str;
}

void getFileModificationTimes() {
    for (size_t i = 0; i < fileInfoCount; ++i) {
        // char fullPath[PATH_MAX];
        // snprintf(fullPath, sizeof(fullPath), "%s/%s", fileInfos[i].path, fileInfos[i].name);

        struct stat fileStat;
        if (stat(fileInfos[i].fullPath, &fileStat) == 0) {
            // Getting the modification time of a document
            time_t modTime = fileStat.st_mtime;
            // Convert timestamps to local time and format as a string
            struct tm *localTime = localtime(&modTime);
            char timeStr[256];
            strftime(timeStr, sizeof(timeStr), "%Y-%m-%d %H:%M:%S", localTime);
            printf("File: %s, Modification time: %s\n", fileInfos[i].fullPath, timeStr);
        } else {
            perror("stat");
        }
    }
}

void printFileNames() {
    for (size_t i = 0; i < fileInfoCount; ++i) {
        char* modTimeStr = ctime(&fileInfos[i].modifiedTime);  // Convert time_t to string
        modTimeStr[strlen(modTimeStr) - 1] = '\0';  // Remove the newline character added by ctime
        printf("File %zu: path:%s    name:%s    fullpath:%s    modifiedTime:%s    mode:%o\n",
               i + 1, fileInfos[i].path, fileInfos[i].name, fileInfos[i].fullPath, modTimeStr, fileInfos[i].fileMode & (S_IRWXU | S_IRWXG | S_IRWXO));
    }

    // Print directory-specific file information
    for (size_t i = 0; i < directoryCount; ++i) {
        printf("Directory %zu: dirName:%s    fullPath:%s\n", i + 1, directories[i].dirName, directories[i].fullPath);
        for (size_t j = 0; j < directories[i].fileInfoCount; ++j) {
            char* modTimeStr = ctime(&directories[i].fileInfos[j].modifiedTime);  // Convert time_t to string
            modTimeStr[strlen(modTimeStr) - 1] = '\0';  // Remove the newline character added by ctime
            printf("    File %zu: path:%s    name:%s    fullpath:%s    modifiedTime:%s    mode:%o\n",
                   j + 1, directories[i].fileInfos[j].path, directories[i].fileInfos[j].name, directories[i].fileInfos[j].fullPath, modTimeStr, directories[i].fileInfos[j].fileMode & (S_IRWXU | S_IRWXG | S_IRWXO));
        }
    }
    // 输出 iPatterns 数组的值
    printf("iPatterns:\n");
    for (size_t i = 0; i < iPatternCount; ++i) {
        char *globPattern = iPatterns[i].globPattern;
        printf("Pattern %zu: glob: %s\n", i + 1, globPattern);
    }

    // 输出 oPatterns 数组的值
    printf("oPatterns:\n");
    for (size_t i = 0; i < oPatternCount; ++i) {
        char *globPattern = oPatterns[i].globPattern;
        printf("Pattern %zu: glob: %s\n", i + 1, globPattern);
    }
}

int isDirectory(const char *path) {
    struct stat statbuf;
    if (stat(path, &statbuf) != 0)
        return 0;
    return S_ISDIR(statbuf.st_mode);
}
