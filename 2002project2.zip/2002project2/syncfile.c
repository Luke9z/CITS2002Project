#include "mysync.h"

// Synchronize files in all directories
void synchronizeDirectories(int nflag, int pflag) {
    for (size_t i = 0; i < fileInfoCount; ++i) {
        FileInfo *mainFileInfo = &fileInfos[i];
        
        // Find the latest version of the file
        FileInfo *latestFileInfo = mainFileInfo;
        for (size_t j = 0; j < fileInfoCount; ++j) {
            if (i != j && strcmp(mainFileInfo->name, fileInfos[j].name) == 0 &&
                fileInfos[j].modifiedTime > latestFileInfo->modifiedTime) {
                latestFileInfo = &fileInfos[j];
            }
        }

        // Copy the latest version of the file to another directory
        for (size_t d = 0; d < directoryCount; ++d) {
            char subdirPath[PATH_MAX];
            snprintf(subdirPath, sizeof(subdirPath), "%s%s/", 
                     directories[d].fullPath, 
                     latestFileInfo->path + strlen(directories[0].fullPath));

            char *lastSlash = strrchr(subdirPath, '/');
            if (lastSlash) {
                *lastSlash = '\0';  // Temporary termination of strings to remove filenames
                if(nflag==0){
                createDirectory(subdirPath);  // Creating subdirectories
                }
                *lastSlash = '/';  // Restore String
            }

            if (strncmp(latestFileInfo->path, directories[d].fullPath, strlen(directories[d].fullPath)) != 0) {
                printf("copying %s to dir  %s \n", latestFileInfo->fullPath, subdirPath);
                if (nflag==0)
                {
                    copyFile(latestFileInfo->fullPath, subdirPath, 4096,  pflag ? latestFileInfo->modifiedTime : 0, pflag ? latestFileInfo->fileMode : 0);
                } 
            }
        }
    }
}