#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <getopt.h>
#include <regex.h>
#include <dirent.h>
#include <limits.h>
#include <sys/types.h>
#include <linux/limits.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#include <utime.h>

/*
//  CITS2002 Project 2 2023
//  Student1:   23371027   Xiaoyu Huang
//  Student2:   23734789   Feiyue Zhang
*/


//-----------------Things in helperfunction.c-----------------------
// Generic Error Reporting Functions
extern void reportError(const char *errorMessage); 

extern char *strdup(const char *str);

// Used to get the modification date of all files within the current structure
extern void getFileModificationTimes(); 

// print out all the details
extern void printFileNames();

extern int isDirectory(const char *path);

//-----------------Things in pattern.c------------------------------
//  
//  CONVERT A FILENAME PATTERN (a glob) TO A REGULAR EXPRESSION.
//  FILENAME PATTERNS MAY NOT INCLUDE DIRECTORY SEPARATORS.
//	ON SUCCESS - A REGULAR EXPRESSION WILL BE RETURNED IN DYNAMICALLY
//		     ALLOCATED MEMORY.
//	ON FAILURE - A NULL POINTER WILL BE RETURNED.
extern char *glob2regex(char *glob);

typedef struct {
    regex_t regex;
    char* globPattern;
} Pattern;

extern Pattern* iPatterns;
extern size_t iPatternCount;

extern Pattern* oPatterns;
extern size_t oPatternCount;

// ADD patterns in iPatterns or oPatterns
extern void addPattern(Pattern** patterns, size_t* patternCount, char* glob);
// Identifies whether the current filename matches the wildcard character
extern int isFileMatchingPatterns(Pattern* patterns, size_t patternCount, const char* filename); 
// ----------------------------------------

// ==============Things in findfile.c============================
// The structure represents the path and name of the file
typedef struct {
    char* path;
    char* name;
    char* fullPath;
    time_t modifiedTime;  // Used to store the modification time of a file
    mode_t fileMode;  // Indicates the operating privileges of the file
} FileInfo;

// Dynamic array for storing file information
extern FileInfo* fileInfos;
extern size_t fileInfoCount;

// Structures represent directory information
typedef struct {
    char* dirName;
    char* fullPath;
    FileInfo* fileInfos;
    size_t fileInfoCount;
} DirectoryInfo;

// Dynamic array for storing directory information
extern DirectoryInfo* directories;
extern size_t directoryCount;

// Create directory structures
extern void addDirectoryInfo(const char* dirPath, const char* dirName); 

// Functions to add file information to dynamic arrays
extern void addFileInfo(const char* path, const char* name, time_t modTime, mode_t mode); 

// Functions to add directory information to dynamic arrays
extern void addFileInfoToDirectory(size_t directoryIndex, const char* path, const char* name, time_t modTime, mode_t mode); 

// Recursive function to read files and paths in a directory
extern void readDirectory(size_t directoryIndex, const char* directory, int aflag, int rflag); 

extern void readDirectory2(size_t directoryIndex, const char* directory);

// Function to release file information from dynamic arrays
extern void freeFileInfos(); 

extern void freeDirectories(); 
//=========================================


//=================Things in copyfile.c========================
// Reproduction of documents
extern int copyFile(const char *srcPath, const char *destDirectory, size_t bufferSize, time_t modifiedTime, mode_t fileMode);

// Create Directory Functions
extern void createDirectory(const char *path);
//===========================================================



//---------------Things in syncfile.c--------------------------
// Synchronize files in all directories
extern void synchronizeDirectories(int nflag, int pflag);

//--------------------------------------------------------