#include "mysync.h"

char *glob2regex(char *glob)
{
    char *re = NULL;

    if(glob != NULL) {
	re	= calloc(strlen(glob)*2 + 4, sizeof(char));
        if(re == NULL) {
	    return NULL;
	}

	char *r	= re;

	*r++	= '^';
	while(*glob != '\0')
	    switch (*glob) {
		case '.' :
		case '\\':
		case '$' : *r++ = '\\'; *r++ = *glob++;	break;
		case '*' : *r++ = '.';  *r++ = *glob++;	break;
		case '?' : *r++ = '.'; glob++;		break;
		case '/' : free(re);
			   re	= NULL;
			   break;
		default  : *r++ = *glob++;
			   break;
	    }
	if(re) {
	    *r++	= '$';
	    *r		= '\0';
	}
    }
    return re;
}

Pattern* iPatterns = NULL;
size_t iPatternCount = 0;

Pattern* oPatterns = NULL;
size_t oPatternCount = 0;

void addPattern(Pattern** patterns, size_t* patternCount, char* glob) {
    char* regexPattern = glob2regex(glob);
    if (regexPattern == NULL) return;

    Pattern newPattern;
    if (regcomp(&newPattern.regex, regexPattern, REG_NOSUB | REG_EXTENDED) != 0) {
        free(regexPattern);
        return;
    }

    newPattern.globPattern = strdup(glob);
    *patterns = realloc(*patterns, (*patternCount + 1) * sizeof(Pattern));
    if (*patterns == NULL) {
        regfree(&newPattern.regex);
        free(newPattern.globPattern);
        free(regexPattern);
        return;
    }

    (*patterns)[*patternCount] = newPattern;
    (*patternCount)++;
    free(regexPattern);
}

int isFileMatchingPatterns(Pattern* patterns, size_t patternCount, const char* filename) {
    for (size_t i = 0; i < patternCount; i++) {
        if (regexec(&patterns[i].regex, filename, 0, NULL, 0) == 0) {
            return 1;  // File matches this pattern
        }
    }
    return 0;  // File does not match any pattern
}

